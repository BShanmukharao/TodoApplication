import TodoContainer from './components/TodoContainer'

const App = () => (
  <div>
    <TodoContainer />
  </div>
)

export default App
